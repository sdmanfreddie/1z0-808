#!/bin/python3

import random;


# ==================================================================================================
# qs_dict
# ==================================================================================================

#		"q0X" : [
#			"""""", # question
#			"""""", # code
#			"""""", # selection
#			"""""", # anser
#		],	

qs_dict = {

	"Q02" : {
		"max" : 20,
		"q01" : [
			"""Which of following operators in Java can be used with boolean var ? \n       ( multiple selection )""", # question
			"""""", # code
			"""%   :X#
               --  :X#
               +   :X#
               !   :Y#
               ==  :Y#
               <   :X#
               *   :X#
            """, # selection
			"""""", # anser
		],	
		"q02" : [
			"""What statement replace ____ will let code compile successful ? ( multiple selection )""", # question
			"""~// define ./Test.java       \n\n~#
               ~   byte  byte_v1  =  100;     \n~#
               ~   byte  byte_v2  =  1;       \n~#
               ~   ____      v_3  =  x * y;     ~#
            """, # code
			"""byte     :X#
               short    :X#
               int      :Y#
               long     :Y#
               boolean  :X#
               float    :Y#
               double   :Y#
            """, # selection
			"""""", # anser
		],	
		"q03" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                                        \n\n~#
               ~    1: public class Test {                                                    \n\n~#
               ~    2:   public static void main(String[] args) {                             \n\n~#
               ~    3:     int var = 0;                                                         \n~#
               ~    4:     int sum = 0;                                                       \n\n~#
               ~    5:     while( ++var < 5 ) {                                                 \n~#
               ~             sum += 1;                                                          \n~#
               ~           }                                                                  \n\n~#
               ~    6:     String msg1 = "sum = " + sum;                                        \n~#
               ~    7:     String msg2 = ( sum % 2 == 0 ) ? "sum % 2 == 0" : "sum % 2 != 0";  \n\n~#
               ~    8:     System.out.println( msg1 + " : " + msg2 );                         \n\n~#
               ~    8:   }                                                                    \n\n~#
               ~    9: }                                                                          ~
			""", # code
			"""sum = 4 : sum % 2 == 0         :Y#
               sum = 4 : sum % 2 != 0         :X#
               sum = 5 : sum % 2 == 0         :X#
               sum = 5 : sum % 2 != 0         :X#
               code compile faile at line 5.  :X#
               code compile faile at line 7.  :X#
               code compile faile at line 8.  :X#
            """, # selection
			"""""", # anser
		],	
		"q04" : [
			"""What change of following will let code compile successful ? ( multiple selection )""", # question
			"""~ // define ./Test.java                             \n\n~#
               ~    1: public class Test {                         \n\n~#
               ~    2:   public static void main(String[] args) {  \n\n~#
               ~    3:     long  x = 10;                             \n~#
               ~    4:     int   y = x + 90;                         \n~#
               ~    5:   }                                         \n\n~#
               ~    6: }                                               ~
            """, # code
			"""nothong to do. code already compile successful.  :X#
               change type of x at line 3 to int.               :Y#
               change type of x at line 3 to byte.              :X#
               change line 4 to int y = ( int )( x + 90 );.     :Y#
               change type of x at line 4 to short.             :X#
               change type of x at line 4 to long.              :Y#
            """, # selection
			"""""", # anser
		],	
		"q05" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                                                   \n\n~#
               ~       import java.util.List;                                                              \n~#
               ~       import java.util.ArrayList;                                                       \n\n~#
               ~    1: public class Test {                                                               \n\n~#
               ~    2:   public static void main(String[] args) {                                        \n\n~#
               ~    3:     List<Integer> list = new ArrayList<Integer>( Arrays.asList( 10,14,18,22 ) );  \n\n~#
               ~    4:     for( Object o : list ) {                                                      \n\n~#
               ~    5:       System.out.print( o + ", " );                                                 \n~#
               ~    6:       if( o % 6 == 0 ) break;                                                     \n\n~#
               ~    7:     }                                                                             \n\n~#
               ~    8:   } // end method main                                                            \n\n~#
               ~    9: } // end class Test                                                                   ~
            """, # code
			"""10, 14, 18,                   :X#
               10, 14, 18, 22,               :X#
               there is no output            :X#
               code compile fail at line 5.  :X#
               code compile fail at line 6.  :Y#
               code never stop at runtime.   :X#
            """, # selection
			"""""", # anser
		],	
		"q06" : [
			"""How to change following code to get result B ? ( multiple selection )""", # question
			"""~ // define ./Test.java                              \n\n~#
               ~    1: public class Test {                          \n\n~#
               ~    2:   public static void main(String[] args) {   \n\n~#
               ~    3:     int  score = 65;                         \n\n~#
               ~    4:     if( y < 65 ) System.out.println( "C" );  \n\n~#
               ~    5:     else         System.out.println( "B" );  \n\n~#
               ~    6:     else         System.out.println( "A" );  \n\n~#
               ~    7:   } // end method main                       \n\n~#
               ~    8: } // end class Test                              ~
            """, # code
			"""nothong to do. code already compile successful.                              :X#
               change code at line 4 to if      ( score <= 80 ) System.out.println( "C" );\n   change code at line 5 to else if ( score <= 65 ) System.out.println( "B" );\n  :X#
               change code at line 4 to if      ( score >= 80 ) System.out.println( "A" );\n   change code at line 5 to else if ( score >= 65 ) System.out.println( "B" );\n   change code at line 6 to else                    System.out.println( "C" );\n  :Y#
               change code at line 5 to else if ( score <  80 ) System.out.println( "B" );  :Y#
            """, # selection
			"""""", # anser
		],	
		"q07" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                                   \n\n~#
               ~    public class Test {                                                  \n\n~#
               ~      public static void main(String[] args) {                           \n\n~#
               ~        int x = 7;                                                       \n\n~#
               ~        String result = x > 5 ? x % 2 == 0 ? "man" : "woman" : "child";  \n\n~#
               ~        System.out.println( result );                                    \n\n~#
               ~      } // end method main                                               \n\n~#
               ~    } // end class Test                                                      ~
            """, # code
			"""man.                    :X#
               woman.                  :Y#
               child.                  :X#
               5.                      :X#
               7.                      :X#
               compile fail at line 4. :X#
            """, # selection
			"""""", # anser
		],	
		"q08" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                             \n\n~#
               ~    1: public class Test {                         \n\n~#
               ~    2:   public static void main(String[] args) {  \n\n~#
               ~    3:     int x = 24;                             \n\n~#
               ~    4:     y = x ^ ( x >> 2 );                     \n\n~#
               ~    5:     System.out.println( "y = " + y );       \n\n~#
               ~    6:   } // end method main                      \n\n~#
               ~    7: } // end class Test                             ~
            """, # code
			"""30.                      :Y#
               25.                      :X#
               15.                      :X#
               there is none output     :X#
               7.                       :X#
               compile fail at line 4.  :X#
            """, # selection
			"""""", # anser
		],	
		"q09" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~  // define ./Test.java                             \n\n~#
               ~     1: public class Test {                         \n\n~#
               ~     2:   public static void main(String[] args) {  \n\n~#
               ~     3:     for( int i=1 ; i<5 ; ) {                \n\n~#
               ~     4:        i = i++;                             \n\n~#
               ~     5:     }                                       \n\n~#
               ~     6:     System.out.println( i );                \n\n~#
               ~     7:   } // end method main                      \n\n~#
               ~     8: } // end class Test                             ~
            """, # code
			"""5.                                  :X#
               1.                                  :X#
               4.                                  :X#
               there is no output                  :X#
               6.                                  :X#
               the program never stop at running.  :X#
               compile fail at line 6.             :Y#
            """, # selection
			"""""", # anser
		],	
		"q10" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                            \n\n~#
               ~    public class Test {                           \n\n~#
               ~      public static void main(String[] args) {    \n\n~#
               ~        byte a = 40, b = 50;                      \n\n~#
               ~        run ( a, b );                             \n\n~#
               ~        System.out.print( a + ", " + b + ", " );  \n\n~#
               ~      } // end method main                        \n\n~#
               ~      public static void run ( int a, int b ) {   \n\n~#
               ~        a = a + 10;                                 \n~#
               ~        b = b + 20;                                 \n~#
               ~        System.out.print( a + ", " + b + ", " );  \n\n~#
               ~      }                                           \n\n~#
               ~    } // end class Test                               ~
            """, # code
			"""50, 70, 50, 70, .  :X#
               40, 50, 40, 50, .  :X#
               50, 70, 40, 50, .  :Y#
               undefined value .  :X#
            """, # selection
			"""""", # anser
		],	
		"q11" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                        \n\n~#
               ~ 1: public class Test {                         \n~#
               ~ 2:   public static void main(String[] args) {  \n~#
               ~ 3:     int result = 65 % 10 * 3;               \n~#
               ~ 4:     System.out.println( result );           \n~#
               ~ 5:   }                                         \n~#
               ~    }                                             ~
            """, # code
			"""1.                            :X#
               5.                            :X#
               10.                           :X#
               15.                           :Y#
               code compile fail at line 3.  :X#
            """, # selection
			"""""", # anser
		],	
		"q12" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                           \n\n~#
               ~ 1: public class Test {                                            \n~#
               ~ 2:   public static void main(String[] args) {                   \n\n~#
               ~ 3:     int    value = 0;                                        \n\n~#
               ~ 4:     String str   = null;                                     \n\n~#
               ~ 5:     if( x == s ) System.out.println( "Equals, " );             \n~#
               ~ 6:     else         System.out.println( "not Equals, " );       \n\n~#
               ~ 7:     if( x.equals( s ) ) System.out.println( "Equals " );       \n~#
               ~ 8:     else                System.out.println( "not Equals " ); \n\n~#
               ~ 9:   }                                                            \n~#
               ~    }                                                                ~
            """, # code
			"""Equals, Equals                      :X#
               Equals, not Equals                  :X#
               not Equals, Equals                  :X#
               not Equals, not Equals              :X#
               compile faile at line 4.            :X#
               compile faile at line 5.            :Y#
               get NullPointException at runtime.  :X#
            """, # selection
			"""""", # anser
		],	
		"q13" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                                                                                     \n\n~#
               ~ 1: public class Test {                                                                                                    \n\n~#
               ~ 2:   public static String yesL() {                                                                                          \n~#
               ~        return " is a leap year.";                                                                                           \n~#
               ~      }                                                                                                                    \n\n~#
               ~ 3:   public static String noL() {                                                                                           \n~#
               ~        return " not a leap year.";                                                                                          \n~#
               ~      }                                                                                                                    \n\n~#
               ~ 4:   public static void main(String[] args) {                                                                             \n\n~#
               ~ 5:     int year = 2036;                                                                                                     \n~#
               ~ 6:     String str = ( ( year % 4 == 0 ) ? ( year % 100 == 0 ) ? ( year % 400 == 0 ) ? yesL() : noL() : yesL() : noL() );  \n\n~#
               ~ 7:     System.out.println( year + str );                                                                                  \n\n~#
               ~ 8:   }                                                                                                                    \n\n~#
               ~    }                                                                                                                          ~
            """, # code
			"""2036 not a leap year      :X#
               2036 is  a leap year      :Y#
               compile faile at line 6.  :X#
               compile faile at line 7.  :X#  
               none output here.         :X#
            """, # selection
			"""""", # anser
		],	
		"q14" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                          \n\n~#
               ~ 1: public class Test {                         \n\n~#
               ~ 2:   public static void main(String[] args) {  \n\n~#
               ~ 3:     int    a  = 0;                            \n~#
               ~ 4:     int    b  = 5;                            \n~#
               ~ 5:     int  sum  = 0;                          \n\n~#
               ~ 6:     for ( int i = a ; i < b ; i++ )           \n~#
               ~ 7:         sum += ++a + a++;                   \n\n~#
               ~ 8:     System.out.println( sum );              \n\n~#
               ~ 9:   }                                         \n\n~#
               ~    }                                               ~
            """, # code
			"""10.                                           :X#
               16.                                           :X#
               32.                                           :X#
               30.                                           :X#
               50.                                           :Y#
               The code will not compile because of line 7.  :X#
            """, # selection
			"""""", # anser
		],	
		"q15" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                          \n\n~#
               ~ 1: public class Test {                         \n\n~#
               ~ 2:   public static void main(String[] args) {  \n\n~#
               ~ 3:     int    a  = 1;                            \n~#
               ~ 4:     int    b  = 8;                          \n\n~#
               ~ 5:     while ( a < b )                           \n~#
               ~ 7:         a += ++a;                             \n~#
               ~ 8          b--;                                \n\n~#
               ~ 9:     System.out.println( a + ", " + b );     \n\n~#
               ~10:   }                                         \n\n~#
               ~    }                                               ~
            """, # code
			"""0, 0                            :X#
               15, 4                           :X#
               3, 4                            :X#
               15, 7                           :Y#
               1, 15                           :X#
               program never stop at runtime.  :X#
            """, # selection
			"""""", # anser
		],	
		"q16" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                          \n\n~#
               ~ 1: public class Test {                         \n\n~#
               ~ 2:   private static int res = 5;               \n\n~#
               ~ 3:   public static void main(String[] args) {  \n\n~#
               ~ 4:     do {                                    \n\n~#
               ~ 5:       int res = 1;                            \n~#
               ~ 6:       System.out.print( ++res + " " );      \n\n~#
               ~ 7:     } while( res <= 10 );                   \n\n~#
               ~ 8:   }                                         \n\n~#
               ~    }                                               ~
            """, # code
			"""1 2 3 4 5 6 7 8 9 10            :X#
               1 2 3 4 5                       :X#
               compile faile at line 7         :X#
               5 6 7 8 9 10                    :X#
               there is none any output        :X#
               program never stop at runtime.  :Y#
            """, # selection
			"""""", # anser
		],	
		"q17" : [
			"""How to print 1 3 5 7 9  ? ( single selection )\n        How to print 2 4 6 8 10 ? ( single selection )""", # question
			"""~ // define ./Test.java                          \n\n~#
               ~ 1: public class Test {                         \n\n~#
               ~ 3:   public static void main(String[] args) {  \n\n~#
               ~ 4:     int count = 1;                            \n~#
               ~ 5:     int num   = 0;                          \n\n~#
               ~ 6:     do {                                      \n~#
               ~ 7:        ++num;                                 \n~#
               ~ 8:        // REPLACE LINE                        \n~#
               ~ 9:        System.out.print( num + " " );         \n~#
               ~10:     } while( ++count <= 10 );               \n\n~#
               ~11:   }                                         \n\n~#
               ~    }                                               ~
            """, # code
			"""change code if( count % 2 == 0 ) continue; at line 8  :Y#
               nothing to do                                         :X#
               change code if( count % 2 == 0 ) break   ; at line 8  :X#
               change code if( count % 2 != 0 ) continue; at line 8  :Y#
               change code if( count % 2 != 0 ) break   ; at line 8  :X#
               code does not compile above.                          :X#
            """, # selection
			"""""", # anser
		],	
		"q18" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                       \n\n~#
               ~ 1: public class Test {                                      \n\n~#
               ~ 2:   public static void main(String[] args) {               \n\n~#
               ~ 3:     int count = 0;                                         \n~#
               ~ 4:     LOOP: for ( int r = 0; r <=3; r++ )                    \n~#
               ~ 5:               for ( int c = 0; c <=2 ; c++ ) {             \n~#
               ~ 6:                   if ( ( r + c ) % 2 == 0 ) continue LOOP; \n~#
               ~ 7:                      count++;                              \n~#
               ~ 8:               }                                            \n~#
               ~ 9:           System.out.println( count );                   \n\n~#
               ~10:   }                                                      \n\n~#
               ~    }                                                            ~
            """, # code
			"""3.                        :X#
               6.                        :X#
               1.                        :X#
               2.                        :Y#
               4.                        :X#
               compile faile at line 6.  :X#
            """, # selection
			"""""", # anser
		],	
		"q19" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                          \n\n~#
               ~ 1: public class Test {                         \n\n~#
               ~ 2:   public static void main(String[] args) {  \n\n~#
               ~ 3:     int m = 9, n = 1, x = 0;                \n\n~#
               ~ 4:     while( true ) {                           \n~#
               ~ 5:       m--;                                    \n~#
               ~ 6:       n += 2;                                 \n~#
               ~ 7:       x += m + n;                             \n~#
               ~ 8:       if ( m > n ) continue;                  \n~#
               ~ 9:       if ( m < n ) break;                     \n~#
               ~10:     }                                         \n~#
               ~11:     System.out.println( x );                \n\n~#
               ~12:   }                                         \n\n~#
               ~    }                                               ~""", # code
			"""this program is never stop at runtime  :X#
               13                                     :X#
               23                                     :X#
               36                                     :Y#
               11                                     :X#
               code compile faile at line 11.         :X#
            """, # selection
			"""""", # anser
		],	
		"q20" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ 1: public class Test {                           \n\n~#
               ~ 2:   public static void main(String[] args) {    \n\n~#
               ~ 3:     int     score  = 60;                        \n~#
               ~ 4:     String  getstr = "";                        \n~#
               ~ 5:     switch( score ) {                           \n~#
               ~          case  0  : getstr = "D";   break;         \n~#
               ~          case 15  : getstr = "C";   break;         \n~#
               ~          case 30  : getstr = "B";   break;         \n~#
               ~          case 45  : getstr = "A";   break;         \n~#
               ~          case 60  : getstr = "S";   break;         \n~#
               ~          case 90  : getstr = "SS";  break;         \n~#
               ~          case 105 : getstr = "SSS"; break;         \n~#
               ~        }                                           \n~#
               ~        System.out.print( "you get " + getstr );  \n\n~#
               ~ 6:   }                                           \n\n~#
               ~    }                                                 ~
            """, # code
			"""none any output here     :X#
               compile faile at line 5  :X#
               you get SSS              :X#
               you get SS               :X#
               you get S                :Y#
            """, # selection
			"""""", # anser
		],	
#		"q0X" : [
#			"""""", # question
#			"""""", # code
#			"""""", # selection
#			"""""", # anser
#		],	
	}

}
                            


# ==================================================================================================
# get_all_random method
# ==================================================================================================

def get_all_random ( obj ) : 

	ans_en = [ "A","B","C","D","E","F","G","H","I","J","K","L","M" ];

	# print( "debug using :: obj : " + str( obj ) );
	# print( "debug using :: len( obj ) : " + str( len( obj ) ) );
	index_list = [ o for o in range( len( obj ) ) ];
	obj2       = [];
	# print( "debug using :: index_list : " + str( index_list ) );
	# print( "debug using :: len( index_list ) : " + str( len( index_list ) ) );

	for i in range ( len( obj ) ) : 
		# print( "01 :: choice from :: " + str( index_list ) );
		tmp = random.choice( index_list );
		# print( "02 :: get this o  :: " + str( tmp ) );
		index_list.pop( index_list.index( tmp ) );
		obj2.append( obj[tmp].strip() );
		pass;
		
	obj2 = [ ans_en[ o ] + ": " + obj2[ o ] for o in range( len( obj2 ) ) ];

	# ----------------------------------------
	# debug using :: print tmp2 elements
	# ----------------------------------------
	
	# for s in obj2 :
	# 	tmp = s.strip();
	# 	print( ">>> " + str ( tmp ) );
	# 	pass;
	
	return obj2;
	pass;


# ==================================================================================================
# dict_update method
# ==================================================================================================

def dict_update ( qs_dict, n1 , n2 ) : 

	ans_en = [ "A","B","C","D","E","F","G","H","I","J","K","L","M" ];

	q = qs_dict.get( n1 ).get( n2 )[2].split( "#" );
	q = [ o for o in q if ( len( o.strip() ) > 0 ) ];
	q = get_all_random( q );
	a = [];
	index = 0;
	for s in q :
		tmp = s.strip();
		# print( ">>> " + str ( tmp ) );
		if( ":Y" in s ) : 
			a.append( ans_en[ index ] );
		q[ index ] = s[ 0:-2 ].strip();
		index += 1;
		pass;
		
	q2 = qs_dict.get( n1 ).get( n2 )[1];
	q2 = "".join( [ o.strip()[ 1:-1 ] for o in q2.split( "#" ) if ( len( o ) > 0 ) ] );

	qs_dict.get( n1 ).update( { n2 : [ 
		                                     qs_dict.get( n1 ).get( n2 )[0] , 
		                                     q2                               , 
		                                     q                                ,
		                                     a                                ,
		                                   ]
		                          } 
		                       );
		                       
	# print( "debug using :: q : " + str( q   ) );
	# print( "debug using :: a : " + str( a   ) );
	# print( "debug using :: qs_dict : " + str( qs_dict ) );
	
	pass;

	
Q_index = [ "", "Q01","Q02","Q03","Q04","Q05","Q06","Q07","Q08","Q09","Q10","Q11","Q12","Q13","Q14","Q15", ];
q_index = [ "", 
	"q01","q02","q03","q04","q05","q06","q07","q08","q09","q10","q11","q12","q13","q14","q15", 
	"q16","q17","q18","q19","q20","q21","q22","q23","q24","q25","q26","q27","q28","q29","q30", 
	"q31","q32","q33","q34","q35","q36","q37","q38","q39","q40","q41","q42","q43","q44","q45", 
];



# ==================================================================================================
# 01
# ==================================================================================================

dict_update( qs_dict, Q_index[ 2 ] , q_index[ 1 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) )


# ==================================================================================================
# 02
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 2 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 03
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 3 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 04
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 4 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 05
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 5 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 06
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 6 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 07
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 7 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 08
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 8 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 09
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 9 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 10
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 10 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 11
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 11 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 12
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 12 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 13 none this
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 13 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 14
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 14 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 15
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 15 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 16
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 16 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 17
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 17 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 18
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 18 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 19
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 19 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 20
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 2 ] , q_index[ 20 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


def get_dict () :
	return qs_dict;
	pass;


