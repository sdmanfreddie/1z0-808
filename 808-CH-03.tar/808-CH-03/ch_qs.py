#!/bin/python3

import random;


# ==================================================================================================
# qs_dict
# ==================================================================================================

#		"q0X" : [
#			"""""", # question
#			"""""", # code
#			"""""", # selection
#			"""""", # anser
#		],	

qs_dict = {

	"Q03" : {
		"max" : 32,
		"q01" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                          \n\n~#
               ~ 1: public class Test {                         \n\n~#
               ~ 2:   public static void main(String[] args) {  \n\n~#
               ~ 3:     int    num = 10;                          \n~#
               ~ 4:     String msg = 10 + " fish get.";         \n\n~#
               ~ 6:     System.out.println( msg );              \n\n~#
               ~ 8:   }                                         \n\n~#
               ~    }                                               ~
            """, # code
			"""10 fish get.           :Y#
               code does not compile. :X#
            """, # selection
			"""""", # anser
		],	
		"q02" : [
			"""What is the result of following ? ( multiple selection )""", # question
			"""~ // define ./Test.java                                              \n\n~#
               ~ 1: public class Test {                                             \n\n~#
               ~ 2:   public static void main(String[] args) {                      \n\n~#
               ~ 3:     String s1 = "Hello";                                          \n~#
               ~ 4:     String s2 = new String( s1 );                               \n\n~#
               ~ 5:     if ( "Hello".equals( s1 ) ) System.out.println( "one"   );    \n~#
               ~ 6:     if ( s2 == s1             ) System.out.println( "two"   );    \n~#
               ~ 7:     if ( s2.equals( s1 )      ) System.out.println( "three" );    \n~#
               ~ 8:     if ( "Hello" == s1        ) System.out.println( "four"  );    \n~#
               ~ 9:     if ( "Hello" == s2        ) System.out.println( "five"  );  \n\n~#
               ~10:   }                                                             \n\n~#
               ~    }                                                                   ~
            """, # code
			"""one                     :Y#
               two                     :X#
               three                   :Y#
               four                    :Y#
               five                    :X#
               code does not compile.  :X#
            """, # selection
			"""""", # anser
		],	
		"q03" : [
			"""What are true about following ? ( multiple selection )""", # question
			"""""", # code
			"""immutable obj can   be modified.           :X#
               immutable obj can't be modified.           :Y#
               immutable obj can   be garbage collected.  :Y#
               immutable obj can't be garbage collected.  :X#
               String        is a immutable obj.          :Y#
               StringBuffer  is a immutable obj.          :X#
               StringBuilder is a immutable obj.          :X#
            """, # selection
			"""""", # anser
		],	
		"q04" : [
			"""What is the result of following ? ( multiple selection )""", # question
			"""~ // define ./Test.java                                    \n\n~#
               ~ 1: public class Test {                                   \n\n~#
               ~ 2:   public static void main(String[] args) {            \n\n~#
               ~ 3:     StringBuffer sb = new StringBuffer( "0123456" );    \n~#
               ~ 4:     sb.insert( 1, 9 ).replace( 2, 5, "876" );           \n~#
               ~ 5:     System.out.println( sb );                         \n\n~#
               ~ 6:   }                                                   \n\n~#
               ~    }                                                         ~
            """, # code
			"""987656                       :X#
               9876456                      :X#
               0987656                      :X#
               09876456                     :Y#              
               throw exception at runtime.  :X#
               code does not compile.       :X#
            """, # selection
			"""""", # anser
		],
		"q05" : [
			"""What is the result of following ? ( multiple selection )""", # question
			"""~ // define ./Test.java                               \n\n~#
               ~ 1: public class Test {                              \n\n~#
               ~ 2:   public static void main(String[] args) {       \n\n~#
               ~ 3:     String        s1 = "JAVA";                     \n~#
               ~ 4:     StringBuilder s2 = new StringBuilder( s1 );  \n\n~#
               ~ 5:     if ( s1 == s2 )                                \n~#
               ~ 6:         System.out.print( "1" );                 \n\n~#
               ~ 7:     if ( s1.equals( s2 ) )                         \n~#
               ~ 8:         System.out.print( "2" );                 \n\n~#
               ~ 9:   }                                              \n\n~#
               ~    }                                                    ~
            """, # code
			"""1                          :X#
               2                          :X#
               12                         :X#
               there is none any output.  :X#
               get exception at runtime.  :X#
               code does not compile.     :Y# 
            """, # selection
			"""""", # anser
		],
		"q06" : [
			"""What is the result of following ? ( multiple selection )""", # question
			"""~ // define ./Test.java                                          \n\n~#
               ~ 1: public class Test {                                         \n\n~#
               ~ 2:   public static void run ( String s1, StringBuffer s2 ) {     \n~#
               ~        s1.concat( " java" );                                     \n~#
               ~        s2.append( " java" );                                     \n~#
               ~      }                                                         \n\n~#
               ~ 3:   public static void main(String[] args) {                  \n\n~#
               ~ 4:     String       s1 = "JAVA";                                 \n~#
               ~ 5:     StringBuffer s2 = new StringBuffer( s1 );                 \n~#
               ~ 6:     run ( s1, s2 );                                           \n~#
               ~ 7:     System.out.println( s1 + ", " + s2 );                     \n~#
               ~ 8:   }                                                         \n\n~#
               ~    }                                                               ~
            """, # code
			"""JAVA, JAVA              :X#
               JAVA java, JAVA java    :X# 
               JAVA, JAVA java         :Y# 
               code does not compile.  :X# 
            """, # selection
			"""""", # anser
		],	
		"q07" : [
			"""What is the result of following ? ( multiple selection )""", # question
			"""~ // define ./Test.java                             \n\n~#
               ~ 1: public class Test {                            \n\n~#
               ~ 2:   public static void main(String[] args) {     \n\n~#
               ~ 3:     String s = "0123456789";\n
               ~ 4:     System.out.print( s.length()    + ", " );    \n~#
               ~ 5:     System.out.print( s.charAt( 3 ) + ", " );    \n~#
               ~ 6:     System.out.print( s.charAt( 6 )        );  \n\n~#
               ~ 7:   }                                            \n\n~#
               ~    }                                                  ~
            """, # code
			"""10, 3, 6                     :Y# 
               10, 4, 7                     :X#
               9, 3, 6                      :X#
               9, 4, 7                      :X#
               code compile fail at line 6. :X#
			""", # selection
			"""""", # anser
		],	
		"q08" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                          \n\n~#
               ~ 1: public class Test {                                         \n\n~#
               ~ 2:   public static String getSubStr( String str, int index ) {   \n~#
               ~        String[] ary = str.split( " " );                          \n~#
               ~        return ary[ index-1 ];                                    \n~#
               ~      }                                                          \n\n~#
               ~ 3:   public static void main(String[] args) {                   \n\n~#
               ~ 4:     String s = "I am a teacher. You are a student.";           \n~#
               ~ 5:     System.out.print( getSubStr( s, 1 ) );                   \n\n~#
               ~ 6:   }                                                          \n\n~#
               ~    }                                                                ~
            """, # code
			"""I                             :Y#
               am                            :X#
               none any output here.         :X#
               code compile fail at line 5.  :X#
            """, # selection
			"""""", # anser
		],	
		"q09" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                            \n\n~#
               ~ 1: public class Test {                           \n\n~#
               ~ 2:   public static String run ( String str ) {     \n~#
               ~ 3:     return str.toUpperCase().substring( -5 );   \n~#
               ~      }                                           \n\n~#
               ~ 4:   public static void main(String[] args) {      \n~#
               ~ 5:     System.out.print( run( "0123456789" ) );    \n~#                                    
               ~ 6:   }                                           \n\n~#
               ~    }                                                 ~
            """, # code
			"""12345                          :X#
               6789                           :X#
               56789                          :X#
               code compile faile at line 5.  :X#
               there is no ooutput.           :X#
               get a runtime exception.       :Y#
			""", # selection
			"""""", # anser
		],	
		"q10" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                                               \n\n~#
               ~ 1: public class Test {                                                              \n\n~#
               ~ 2:   public static void main(String[] args) {                                       \n\n~#
               ~ 3:     String str = "";                                                               \n~#
               ~ 4:     str += "java ";                                                                \n~#
               ~ 5:     str += "is ";                                                                  \n~#
               ~ 6:     str += (char)97;                                                               \n~#
               ~ 7:     str += " programing";                                                          \n~#
               ~ 8:     if ( str == "java is a programing"        ) System.out.println( "=="     );    \n~#
               ~ 9:     if ( str.equals( "java is a programing" ) ) System.out.println( "equals" );  \n\n~#
               ~10:   }                                                                              \n\n~#
               ~    }                                                                                    ~
            """, # code
			"""compile faile at line 4.   :X#
               compile faile at line 5.   :X#
               compile faile at line 6.   :X#
               compile faile at line 7.   :X#
               ==                         :X#
               equals                     :Y#
               get exception at runtime.  :X#
            """, # selection
			"""""", # anser
		],	
		"q11" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                                     \n\n~#
               ~ 1: public class Test {                                                    \n\n~#
               ~ 2:   public static int countIn( String str, String key, int s, int e ) {    \n~#
               ~        int count = 0;                                                       \n~#
               ~        for ( char c : str.substring( s, e ).toCharArray() ) {               \n~#
               ~ 3:       if ( ( "" + c ).equals( key ) ) count++;                           \n~#
               ~        }                                                                    \n~#
               ~        return count;                                                        \n~#
               ~      }                                                                    \n\n~#
               ~ 4:   public static void main(String[] args) {                             \n\n~#
               ~ 5:     String str = "0989123456";                                           \n~#
               ~ 6:     System.out.println( countIn( str, "9", 0, str.length() ) );        \n\n~#
               ~ 7:   }                                                                    \n\n~#
               ~    }                                                                          ~
            """, # code
			"""1                          :X#
               2                          :Y#
               3                          :X#
               compile faile at line 3.   :X#
               get exception at runtime.  :X#
            """, # selection
			"""""", # anser
		],	
		"q12" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                         \n\n~#
               ~ 1: public class Test {                                        \n\n~#
               ~ 2:   public static void main(String[] args) {                 \n\n~#
               ~ 3:     StringBuilder sb = new StringBuilder( "0123456789" );    \n~#
               ~ 4:     sb.delete( 2, 5 );                                       \n~#
               ~ 5:     sb.append( "-" ).insert( 7, "+" );                       \n~#
               ~ 6:     System.out.println( sb );                              \n\n~#
               ~ 7:   }                                                        \n\n~#
               ~    }                                                              ~
            """, # code
			"""01+89–                     :X#
               0123456789                 :X#
               016789+-                   :X#
               0156789+-                  :Y#
               get exception at runtime.  :X#
               code does not compile.     :X#
			""", # selection
			"""""", # anser
		],	
		"q13" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                               \n\n~#
               ~ 1: public class Test {                                              \n\n~#
               ~ 2:   public static void main(String[] args) {                       \n\n~#
               ~        public static String deleteAt( String str, int s, int e ) {  \n\n~#
               ~          StringBuilder sb = new StringBuilder();                      \n~#
               ~          int index = 0;                                               \n~#
               ~          for ( char c : str.toCharArray() ) {                         \n~#
               ~            if ( ! ( index >= s && index < e ) )                       \n~#
               ~ 3:            sb.append( c );                                         \n~#
               ~            index++;                                                   \n~#
               ~          }                                                            \n~#
               ~          return sb.toString();                                      \n\n~#
               ~        }                                                            \n\n~#
               ~      public static void main ( String[] argu ) {                    \n\n~#
               ~ 4:     String str =  "I am a teacher, You are a student.";            \n~#
               ~ 5:     System.out.println( deleteAt( str, 0, 16 ) );                \n\n~#
               ~ 6:   }                                                              \n\n~#
               ~    }                                                                    ~
            """, # code
			""""I am a teacher, You are a student."  :X#
               " You are a student."                 :X#
               "You are a student."                  :Y#
               get exception at runtime.             :X#
               code does not compile.                :X#
            """, # selection
			"""""", # anser
		],	
		"q14" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                            \n\n~#
               ~ 1: public class Test {                                           \n\n~#
               ~      public static String reverse( String str, int s, int e ) {  \n\n~#
               ~        StringBuilder sb = new StringBuilder();                     \n~#
               ~        char[] tmp = str.toCharArray();                             \n~#
               ~        for ( int i = tmp.length ; i > -1 ; i-- ) {                 \n~#
               ~            if ( i >= s && i < e )                                  \n~#
               ~               sb.append( tmp[ i ] );                               \n~#
               ~        }                                                           \n~#
               ~        return sb.toString();                                     \n\n~#
               ~      }                                                           \n\n~#
               ~ 2:   public static void main ( String[] argu ) {                 \n\n~#
               ~ 3:     String str =  "0123456789";                                 \n~#
               ~ 4:     System.out.println( reverse( str, 5, 9 ) );               \n\n~#
               ~ 5:   }                                                           \n\n~#
               ~    }                                                                 ~                                                                  ~
            """, # code
			""""0123456789"               :X#
               "9876543210"               :X#
               "8765"                     :Y#
               get exception at runtime.  :X#
               code does not compile.     :X#
			""", # selection
			"""""", # anser
		],	
		"q15" : [
			"""What are true of following ? ( multiple selection )""", # question
			"""""", # code
			"""Integer[][]       a1   = new Integer[1][]        ;  :Y#
               Object[][][]      a2   = new Object[5][0][5]     ;  :Y#
               String            a3[] = new beans[1]            ;  :Y#
               java.util.Date[]  a4[] = new java.util.Date[1][] ;  :Y#
               Integer[][]       a5   = new Integer[]           ;  :X#
               Integer[][]       a6   = new Integer[][]         ;  :X#
			""", # selection
			"""""", # anser
		],	
		"q16" : [
			"""What are true of following ? ( multiple selection )""", # question
			"""""", # code
			"""array     has fixed size after new it.   :Y#
               ArrayList has fixed size after new it.   :X#
               array     allow dimension large than 1.  :Y#
               ArrayList allow dimension large than 1.  :X#
               array     can be sorted.                 :Y#
               ArrayList can be sorted.                 :Y#
               array     is an immutable obj.           :X#
               ArrayList is an immutable obj.           :X#
            """, # selection
			"""""", # anser
		],	
		"q17" : [
			"""What are true of following ? ( multiple selection )""", # question
			"""""", # code
			"""Arrays.equals( a1, a2 )      return true when array     a1 and a2 have the same content. :Y#
               ArrayLists.equals( a1, a2 )  return true when ArrayList a1 and a2 have the same content. :X#
               a1.equals( a2 )              return true when ArrayList a1 and a2 have the same content. :Y#
               If you will remove a element from empty ArrayList, it will compile successfull.          :Y#
               If you will remove a element from empty ArrayList, it will run     successfull.          :X#
               none of above.                                                                           :X#
			""", # selection
			"""""", # anser
		],	
		"q18" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                             \n\n~#
               ~ 1: public class Test {                            \n\n~#
               ~ 2:   public static void main ( String[] argu ) {  \n\n~#
               ~ 3:     List<Integer> list = new ArrayList<>();      \n~#
               ~ 4:     list.add(  1  );                             \n~#
               ~ 5:     list.add(  2  );                             \n~#
               ~ 6:     list.add( "3" );                           \n\n~#
               ~        for ( Integer i : list ) {                   \n~#
               ~            System.out.print( i + " " );             \n~#
               ~        }                                          \n\n~#
               ~ 4:   }                                            \n\n~#
               ~    }                                                  ~
            """, # code
			"""1 2 3                         :X#
               1 2                           :X#
               1 2 followed by an exception  :X#
               compil fail at line 5.        :X#
               compil fail at line 6.        :Y#
            """, # selection
			"""""", # anser
		],	
		"q19" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                             \n\n~#
               ~ 1: public class Test {                            \n\n~#
               ~ 2:   public static void main ( String[] argu ) {  \n\n~#
               ~ 3:     List<Integer> list = new ArrayList<>();      \n~#   
               ~        list.add( 1 );                               \n~# 
               ~        list.add( 2 );                               \n~# 
               ~        list.add( 3 );                               \n~# 
               ~        list.set( 2, 30 );                           \n~# 
               ~        list.remove( 2 );                          \n\n~#
               ~ 4:     for ( Integer i : list ) {                   \n~# 
               ~            System.out.print( i + " " );             \n~# 
               ~        }                                          \n\n~#
               ~ 5:   }                                            \n\n~#
               ~    }                                                  ~
            """, # code
			"""1 2 3                         :X#
               1 2                           :Y#
               1 2 followed by an exception  :X#
               compil fail at line 5.        :X#
               compil fail at line 6.        :X#
            """, # selection

			"""""", # anser
		],	
		"q20" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                    \n\n~#
               ~ 1: public class Test {                                   \n\n~#
               ~ 2:   public static void main ( String[] argu ) {         \n\n~#
               ~ 3:     int[] ary = { 20, 45, 12, -99, 50 };                \n~#
               ~ 4:     int key = 12;                                       \n~#
               ~ 5:     int key_index = Arrays.binarySearch( ary, key );    \n~#
               ~ 6:     System.out.println( key_index );                  \n\n~#
               ~ 7:   }                                                   \n\n~#
               ~    }                                                         ~
            """, # code
			"""1                          :X#
               2                          :Y#
               3                          :X#
               result is undefined here.  :X#
               get runtime exception.     :X#
               code does not compile.     :X#
			""", # selection
			"""""", # anser
		],	
		"q21" : [
			"""Which lines can be remove and let code compile successful ? ( single selection )""", # question
			"""~ 1: Collections.sort( Arrays.asList( 10, 4, -1, 5 ) );                             \n~#
               ~ 2: Collections.sort( List.of( 10, 4, -1, 5 ) );                                   \n~#
               ~ 3: Collections.sort( new ArrayList.addAll( 10, 4, -1, 5 ) );                      \n~#
               ~ 4: Collections.sort( new ArrayList( List.of( 10, 4, -1, 5 ) ) );                  \n~#
               ~ 5: Collections.sort( Stream.of( 10, 4, -1, 5 ).collect( Collectors.toList() ) );  \n~#
			""", # code
			"""2 3 4          :X#
               2 5            :X#
               1 2 5          :X#
               none of these  :X#
               2 3            :Y#
			""", # selection
			"""""", # anser
		],	
		"q22" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                               \n\n~#
               ~ 1: public class Test {                              \n\n~#
               ~ 2:   public static void main(String[] args) {       \n\n~#
               ~ 3:     Integer[] nums = { 1, 2, 3 };                  \n~#
               ~ 4:     List<Integer> list = Arrays.asList( nums );    \n~#
               ~ 5:     list.set( 0, 10 );                             \n~#
               ~ 6:     System.out.print( nums[ 0 ] + ", " );        \n\n~#
               ~ 7:     list.sort( ( s, f ) -> f.compareTo( s ) );     \n~#
               ~ 8:     System.out.print( nums[ 1 ] );               \n\n~#
               ~ 9:   }                                              \n\n~#
               ~    }                                                    ~
            """, # code
			"""10, 3                        :Y#
               1, 2                         :X#
               compile fail at line 4.      :X#
               compile fail at line 5.      :X#
               get runtime exception here.  :X#
			""", # selection
			"""""", # anser
		],	
		"q23" : [
			"""What is the result of following ? ( single selection )""", # question
			"""~ // define ./Test.java                                                  \n\n~#
               ~ 1: public class Test {                                                 \n\n~#
               ~ 2:   public static void main(String[] args) {                          \n\n~#
               ~ 3:     List<String> vars = Arrays.asList( "30" , "8" , "3A" , "FF" );    \n~#
               ~ 4:     Collections.sort( vars );                                         \n~#
               ~ 5:     int x = Collections.binarySearch( vars, "8"  );                   \n~#
               ~ 6:     int y = Collections.binarySearch( vars, "3A" );                   \n~#
               ~ 7:     int z = Collections.binarySearch( vars, "4F" );                   \n~#
               ~ 8:     System.out.println( x + " " + y + " " + z );                    \n\n~#
               ~ 9:   }                                                                 \n\n~#
               ~    }                                                                       ~
			""", # code
			"""0 1 –2                 :X#
               0 1 –3                 :X#
               2 1 –2                 :X#
               2 1 –3                 :Y#
               none of above.         :X#
               code doesn’t compile.  :X#
			""", # selection
			"""""", # anser
		],	
		"q24" : [
			"""What are true of following ? ( multiple selection )""", # question
			"""~ // define ./Test.java                                 \n\n~#
               ~ 1: public class Test {                                \n\n~#
               ~ 2:   public static void main(String[] args) {         \n\n~#
               ~ 3:     List<Integer> ages = new ArrayList<>();        \n\n~#
               ~ 4:     ages.add( Integer.parseInt("5") );               \n~#
               ~ 5:     ages.add( Integer.valueOf("6")  );               \n~#
               ~ 6:     ages.add( 7                     );               \n~#
               ~ 7:     ages.add( null                  );             \n\n~#
               ~ 8:     for ( int age : ages ) System.out.print(age);  \n\n~#
               ~ 9:   }                                                \n\n~#
               ~    }                                                      ~
			""", # code
			"""code compiles successful.       :Y#
               get runtime exception here.     :Y#
               line 6       using autoboxing.  :X#
               line 4, 6    using autoboxing.  :Y#
               line 4, 5, 6 using autoboxing.  :X#
			""", # selection
			"""""", # anser
		],	
#		"q0X" : [
#			"""""", # question
#			"""""", # code
#			"""""", # selection
#			"""""", # anser
#		],	



	}
}



# ==================================================================================================
# get_all_random method
# ==================================================================================================

def get_all_random ( obj ) : 

	ans_en = [ "A","B","C","D","E","F","G","H","I","J","K","L","M" ];

	# print( "debug using :: obj : " + str( obj ) );
	# print( "debug using :: len( obj ) : " + str( len( obj ) ) );
	index_list = [ o for o in range( len( obj ) ) ];
	obj2       = [];
	# print( "debug using :: index_list : " + str( index_list ) );
	# print( "debug using :: len( index_list ) : " + str( len( index_list ) ) );

	for i in range ( len( obj ) ) : 
		# print( "01 :: choice from :: " + str( index_list ) );
		tmp = random.choice( index_list );
		# print( "02 :: get this o  :: " + str( tmp ) );
		index_list.pop( index_list.index( tmp ) );
		obj2.append( obj[tmp].strip() );
		pass;
		
	obj2 = [ ans_en[ o ] + ": " + obj2[ o ] for o in range( len( obj2 ) ) ];

	# ----------------------------------------
	# debug using :: print tmp2 elements
	# ----------------------------------------
	
	# for s in obj2 :
	# 	tmp = s.strip();
	# 	print( ">>> " + str ( tmp ) );
	# 	pass;
	
	return obj2;
	pass;


# ==================================================================================================
# dict_update method
# ==================================================================================================

def dict_update ( qs_dict, n1 , n2 ) : 

	ans_en = [ "A","B","C","D","E","F","G","H","I","J","K","L","M" ];

	q = qs_dict.get( n1 ).get( n2 )[2].split( "#" );
	q = [ o for o in q if ( len( o.strip() ) > 0 ) ];
	q = get_all_random( q );
	a = [];
	index = 0;
	for s in q :
		tmp = s.strip();
		# print( ">>> " + str ( tmp ) );
		if( ":Y" in s ) : 
			a.append( ans_en[ index ] );
		q[ index ] = s[ 0:-2 ].strip();
		index += 1;
		pass;
		
	q2 = qs_dict.get( n1 ).get( n2 )[1];
	q2 = "".join( [ o.strip()[ 1:-1 ] for o in q2.split( "#" ) if ( len( o ) > 0 ) ] );

	qs_dict.get( n1 ).update( { n2 : [ 
		                                     qs_dict.get( n1 ).get( n2 )[0] , 
		                                     q2                               , 
		                                     q                                ,
		                                     a                                ,
		                                   ]
		                          } 
		                       );
		                       
	# print( "debug using :: q : " + str( q   ) );
	# print( "debug using :: a : " + str( a   ) );
	# print( "debug using :: qs_dict : " + str( qs_dict ) );
	
	pass;

	
Q_index = [ "", "Q01","Q02","Q03","Q04","Q05","Q06","Q07","Q08","Q09","Q10","Q11","Q12","Q13","Q14","Q15", ];
q_index = [ "", 
	"q01","q02","q03","q04","q05","q06","q07","q08","q09","q10","q11","q12","q13","q14","q15", 
	"q16","q17","q18","q19","q20","q21","q22","q23","q24","q25","q26","q27","q28","q29","q30", 
	"q31","q32","q33","q34","q35","q36","q37","q38","q39","q40","q41","q42","q43","q44","q45", 
];



# ==================================================================================================
# 01
# ==================================================================================================

dict_update( qs_dict, Q_index[ 3 ] , q_index[ 1 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) )


# ==================================================================================================
# 02
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 2 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 03
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 3 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 04
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 4 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 05
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 5 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 06
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 6 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 07
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 7 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 08
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 8 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 09
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 9 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 10
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 10 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 11
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 11 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 12
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 12 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 13 none this
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 13 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 14
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 14 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 15
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 15 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 16
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 16 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 17
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 17 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 18
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 18 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 19
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 19 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 20
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 20 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 21
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 21 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 22
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 22 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 23
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 23 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# 24
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 3 ] , q_index[ 24 ] );
print( "debug using :: qs_dict : " + str( qs_dict ) );

def get_dict () :
	return qs_dict;
	pass;


