
// import java.lang.*;
// import java.lang.System;
import lib.Water;
// import lib.*;

public class Test {
  public void print( Water water ) {
    System.out.println( water ); 
  } 
  public static void main ( String[] argu ) {
    new Test().print( new Water() );
  }
}
