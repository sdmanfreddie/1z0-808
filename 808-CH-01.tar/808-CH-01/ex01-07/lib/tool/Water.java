package lib.tool;
public class Water {
  public boolean ck = false;
}
