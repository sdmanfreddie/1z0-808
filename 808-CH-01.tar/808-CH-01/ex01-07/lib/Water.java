package lib;
public class Water {
  public boolean ck = true;
}
