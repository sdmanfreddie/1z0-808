package worker;

//case A.
	// import lib.*;

//case B.
	// import lib.Water;
	// import lib.tool.*;
	
//case C.
	import lib.*;
	import lib.tool.Water;

//case D.
	// import lib.*;
	// import lib.tool.*;

//case E.
	// import lib.Water;
	// import lib.tool.Water;
		
public class Test {
  Water water = new Water();
  public static void main ( String[] argu ) {
    System.out.println( new Test().water.ck );
  }
}
