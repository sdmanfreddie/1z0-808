#!/bin/python3

import random;


# ==================================================================================================
# qs_dict
# ==================================================================================================

#		"q0X" : [
#			"""""", # question
#			"""""", # code
#			"""""", # selection
#			"""""", # anser
#		],	

qs_dict = {

	"Q01" : {
		"max" : 21,
		"q01" : [
			"""Please select all valid Java identifiers ! ( mutiple selection )""",  # question
			"""""",                                                                  # code
			"""data.1        :X#				                                             
               public_data1  :Y#
               $data1        :Y#
               true          :X#
               1_data        :X#
               _data_1       :Y#
               public        :X#
			""",                                                                     # selection
			"""""",                                                                  # anser
		],
		"q02" : [
			"""Whitch selection is true ? ( single selection )""", # question
			"""~1:  public class Test {                             \n\n~#
               ~2:    private String id;                            \n\n~#
               ~3:    private boolean name;                         \n\n~#
               ~4:    public static void main( String[] argu ) {    \n\n~#
               ~5:      Test test = new Test();                     \n\n~#
               ~6:      System.out.print( "name = " + test.name );  \n\n~#
               ~7:      System.out.print( ", id = " + test.id   );  \n\n~#
               ~8:      System.out.println( "" );                   \n\n~#
               ~9:    }                                             \n\n~#
               ~    }                                                   ~
            """, # code
			"""name = null  , id = null   :X#
               compiler error at Line 6.  :X#
               name = false , id = null   :Y#
               compiler error at Line 7.  :X#
               name = false , id =        :X#
               name = , id =              :X#
               There is no output.        :X#
            """, # selection
			"""""", # anser
		],
		"q03" : [
			"""Which selections are true ? ( mutiple selection )""", # question
			"""~4: short  var1 = 5;             \n~#
               ~5: int    var2 = 5.6;           \n~#
               ~6: String var3 = "Testing";   \n\n~#
               ~7: var1.length();               \n~#
               ~8: var2.length();               \n~#
               ~9: var3.length();                 ~
            """, # code
			"""compiler error at Line 4.  :X#
               compiler error at Line 5.  :Y#
               compiler error at Line 6.  :X#
               compiler error at Line 7.  :Y#
               compiler error at Line 8.  :Y#
               compiler error at Line 9.  :X#
               code compiler successfull. :X#
            """, # selection
			"""""", # anser
		],	
		"q04" : [
			"""Which selections are true ? ( mutiple selection )""", # question
			"""~   //  Given following class ./Test.java  \n\n~#
               ~ 1:  public class Test {                    \n~#
               ~ 2:                                         \n~#
               ~ 3:    public void run( boolean ck ) {      \n~#
               ~ 4:                                         \n~#
               ~ 5:      if ( ck ) {                        \n~#
               ~ 6:                                         \n~#
               ~ 7:      }                                  \n~#
               ~ 8:      System.out.println( res );         \n~#
               ~ 9:                                         \n~#
               ~10:    }                                    \n~#
               ~11:                                         \n~#
               ~12:  }                                        ~
            """, # code
			"""add String res = "done"; at line 2, code will compile successful. :Y#
               add String res = "done"; at line 4, code will compile successful. :Y#
               add String res = "done"; at line 6, code will compile successful. :X#
               add String res = "done"; at line 9, code will compile successful. :X#
               none of these changes will let code compile successful.           :X#
            """, # selection
			"""""", # anser
		],	
		"q05" : [
			"""Which of following change on // INSERT LINE\ncan let code compile successful ? ( mutiple selection )""", # question
			"""~// define ./lib/Mgr.java                          \n\n~#
               ~   package lib;                                     \n~#
               ~   public class Mgr { }                         \n\n\n~#
               ~// define ./lib/tool/Tool.java                    \n\n~#
               ~   package lib.tool;                                \n~#
               ~   public class Tool { }                        \n\n\n~#
               ~// define ./Test.java                             \n\n~#
               ~   // INSERT LINE                                 \n\n~#
               ~   public class Test {                              \n~#
               ~     public void run ( Tool tool ) {                \n~#
               ~       System.out.println( tool );                  \n~#
               ~     }                                              \n~#
               ~     public static void main ( String[] argu ) {    \n~#
               ~       new Test().run( new Tool() );                \n~#
               ~     }                                              \n~#
               ~   }                                                  ~
            """, # code
			"""replace using import lib.*;                             :X#
               replace using import lib.*.Tool;                        :X#
               replace using import lib.tool.Tool;                     :Y#
               replace using import lib.tool.*;                        :Y#
               replace using import lib.tool.Tool.*;                   :X#
               none of these changes will let code compile successful. :X#
            """, # selection
			"""""", # anser
		],	
		"q06" : [
			"""Which of following import can be removed\n, and than it still compile successful ? ( mutiple selection )""", # question
			"""~// define ./lib/Water.java                      \n\n~#
               ~   package lib;                                   \n~#
               ~   public class Water { }                     \n\n\n~#
               ~// define ./Test.java                           \n\n~#
               ~   import java.lang.*;                            \n~#
               ~   import java.lang.System;                       \n~#
               ~   import lib.Water;                              \n~#
               ~   import lib.*;                                \n\n~#
               ~   public class Test {                            \n~#
               ~     public void print( Water water ) {           \n~#
               ~       System.out.println( water );               \n~#
               ~     }                                            \n~#
               ~     public static void main ( String[] argu ) {  \n~#
               ~       new Test().print( new Water() );           \n~#
               ~     }                                            \n~#
               ~   }                                                ~
            """, # code
			"""0                                 :X#
               1                                 :X#
               2                                 :X#
               3                                 :Y#
               4                                 :X#
               code does not compile successful. :X#
            """, # selection
			"""""", # anser
		],	
		"q07" : [
			"""Which of following change on // INSERT LINE\ncan let code compile successful ? ( mutiple selection )""", # question
			"""~// define ./lib/Water.java                        \n\n~#
               ~   package lib;                                     \n~#
               ~   public class Water {                             \n~#
               ~     public boolean ck = true;                      \n~#
               ~   }                                            \n\n\n~#
               ~// define ./lib/tool/Water.java                   \n\n~#
               ~   package lib.tool;                                \n~#
               ~   public class Water {                             \n~#
               ~     public boolean ck = false;                     \n~#
               ~   }                                            \n\n\n~#
               ~// define ./worker/Test.java                      \n\n~#
               ~   package worker;                                \n\n~#
               ~   // INSERT LINE                                 \n\n~#
               ~   public class Test {                              \n~#
               ~     Water water = new Water();                     \n~#
               ~     public static void main ( String[] argu ) {    \n~#
               ~       System.out.println( new Test().water.ck );   \n~#
               ~     }                                              \n~#
               ~   }                                                  ~
            """, # code
			"""import lib.*;                                          \n:Y#
               import lib.Water;\n   import lib.tool.*;               \n:Y#
               import lib.*;\n   import lib.tool.Water;               \n:Y#
               import lib.*;\n   import lib.tool.*;                   \n:X#
               import lib.Water;\n   import lib.tool.Water;           \n:X#
               none of these imports can let code compile successful.   :X#
            """, # selection
			"""""", # anser
		],	
		"q08" : [
			"""Which following calls will get output "ch2 ch3" ? ( single selection )""", # question
			"""~// define ./Test.java                            \n\n~#
               ~   public class Test {                             \n~#
               ~     public static void main( String[] argu ) {    \n~#
               ~       System.out.println( argu[1] );              \n~#
               ~     }                                             \n~#
               ~   }                                                 ~
            """, # code
			"""java Test       ch1 ch2 ch3    :X#
               java Test       ch1 "ch2 ch3"  :Y#
               java Test       ch2 ch3 ch1    :X#
               java Test       "ch2 ch3" ch1  :X#
               java Test.class ch1 "ch2 ch3"  :X#
               java Test.class "ch2 ch3" ch1  :X#
               does not successful.           :X#
            """, # selection
			"""""", # anser
		],	
		"q09" : [
			"""Which of the following can be write into main() method argument\n, and than it compile successful ? ( mutiple selection )""", # question
			"""""", # code
			"""String[]  _argu   :Y#
               String[]  12345   :X#
               String    argu[]  :Y#
               String    _argu[] :Y#
               String... $argu   :Y#
               String    argus   :X#
               none of these.    :X#
            """, # selection
			"""""", # anser
		],	
		"q10" : [
			"""How define entry point main method in java ? ( single selection )""", # question
			"""""", # code
			"""private static void       main( String[] args ) :X#
               public  static      final main( String[] args ) :X#
               public         void       main( String[] args ) :X#
               public  static void       test( String[] args ) :X#
               public  static void       main( String[] args ) :Y#
               public  static            main( String[] args ) :X#
               none of the these.                              :X#
            """, # selection
			"""""", # anser
		],	
		"q11" : [
			"""Which of the following are true ? ( mutiple selection )""", # question
			"""""", # code
			"""instance var of type double init value is null.  :X#
               instance var of type int    init value is null.  :X#
               instance var of type String init value is null.  :Y#
               instance var of type double init value is 0.0.   :Y#
               instance var of type int    init value is 0.0.   :X#
               instance var of type String init value is 0.0.   :X#
               none of these.
            """, # selection
			"""""", # anser
		],	
		"q12" : [
			"""Which of the following are true ? ( mutiple selection )""", # question
			"""""", # code
			"""local var of type boolean init value is null.  :X#
               local var of type float   init value is 0.     :X#
               local var of type Object  init value is null.  :X# 
               local var of type boolean init value is false. :X#
               local var of type boolean init value is true.  :X#
               local var of type float   init value is 0.0.   :X#  
               none of these.                                 :Y#
            """, # selection
			"""""", # anser
		],	
#		"q13" : [
#			"""""", # question
#			"""""", # code
#			"""""", # selection
#			"""""", # anser
#		],	
		"q14" : [
			"""Which of following change on // INSERT LINE\ncan let code compile successful if we compile from /mywork/ path ?\n( mutiple selection )""", # question
			"""~Given the following Test.java in path ./mywork/lib/worker/Test.java:  \n\n~#
               ~// INSERT LINE                                                        \n\n~#
               ~public class Test { }                                                     ~
            """, # code
			"""package mywork.lib.worker;    :X#
               package mywork.lib.Worker;    :X#
               package lib.worker;           :Y#
               package lib.Worker;           :X#
               package worker;               :X#
               package Worker;               :X#
               does not compile successfull. :X#
            """, # selection
			"""""", # anser
		],	
		"q15" : [
			"""Whitch selection is true ? ( mutiple selection )""", # question
			"""""", # code
			"""int    o1 = 1_234;     :Y#
               double o2 = 1_234_.0;  :X#
               double o3 = 1_234._0;  :X#
               double o4 = 1_234.0_;  :X#
               double o5 = 1_234.0;   :Y#
               none of these.         :X#
            """, # selection
			"""""", # anser
		],	
		"q16" : [
			"""Which of following change on // INSERT LINE\ncan let code compile successful ? ( mutiple selection )""", # question
			"""~// define class Test.java        \n\n~#
               ~   public class Test {             \n~#
               ~     public void run() {           \n~#
               ~       // INSERT LINE              \n~#
               ~       System.out.println( var );  \n~#
               ~     }                             \n~#
               ~   }                                 ~
            """, # code
			"""int    var = 9L;        :X#
               int    var = 0b101;     :Y#
               int    var = 0xE;       :Y#
               double var = 0Xe;       :Y#
               double var = 1_2_.0_0;  :X#
               int    var = 1_2_;      :X#
               none of these.          :X#
            """, # selection
			"""""", # anser
		],	
		"q17" : [
			"""Which selections are true ? ( mutiple selection )""", # question
			"""~// define class Test.java                   \n\n~#
               ~   public class Test {                           \n~#
               ~     public static void main( String[] argu ) {  \n~#
               ~       Test test = new Test();                   \n~#
               ~     }                                           \n~#
               ~   }                                               ~
            """, # code
			"""Test is a class.                   :Y#
               test is a class.                   :X#
               main is a class.                   :X#
               Test is a reference to an object.  :X#
               test is a reference to an object.  :Y#
               main is a reference to an object.  :X#
               none of these.                     :X#
            """, # selection
			"""""", # anser
		],	
		"q18" : [
			"""Which order about A, B and C can liet code compile successful ?\n( mutiple selection )""", # question
			"""~A: class Test {}        \n~#
               ~B: import java.util.*;  \n~#
               ~C: package lib;           ~
            """, # code
			"""A, B, C  :X#
               B, C, A  :X#
               C, B, A  :Y#
               B, A     :Y#
               C, A     :Y#
               A, C     :X#
               A, B     :X#
            """, # selection
			"""""", # anser
		],	
		"q19" : [
			"""Which selections are true ? ( mutiple selection )""", # question
			"""~ //  define class Ball.java                         \n\n~#
               ~    1:  public class Ball {                         \n\n~#
               ~    2:    public static void main(String[] args) {  \n\n~#
               ~    3:      Ball one = new Ball();                  \n\n~#
               ~    4:      Ball two = new Ball();                  \n\n~#
               ~    5:      Ball three = one;                       \n\n~#
               ~    6:      one = null;                             \n\n~#
               ~    7:      Ball four = one;                        \n\n~#
               ~    8:      three = null;                           \n\n~#
               ~    9:      two = null;                             \n\n~#
               ~   10:      two = new Ball();                       \n\n~#
               ~   11:      System.gc();                            \n\n~#
               ~   12:    }                                         \n\n~#
               ~        }                                               ~
            """, # code
			"""Ball object from line 3 may be garbage collection item after line 6.   :X#
               Ball object from line 3 may be garbage collection item after line 8.   :Y#
               Ball object from line 3 may be garbage collection item after line 12.  :X#
               Ball object from line 4 may be garbage collection item after line 9.   :Y#
               Ball object from line 4 may be garbage collection item after line 11.  :X#
               Ball object from line 4 may be garbage collection item after line 12.  :X#
            """, # selection
			"""""", # anser
		],	
		"q20" : [
			"""Which selections are true ? ( mutiple selection )""", # question
			"""~// define class ./Test.java                    \n\n~#
               ~   public class Test {                           \n~#
               ~     protected void finalize() {                 \n~#
               ~       System.out.println("final line ! ");      \n~#
               ~     }                                           \n~#
               ~     public static void main( String[] args ) {  \n~#
               ~       Test test = new Test();                   \n~#
               ~       test = null;                              \n~#
               ~       System.gc();                              \n~#
               ~     }                                           \n~#
               ~   }                                               ~
            """, # code
			"""finalize() must be called.                 :X#
               finalize() might or might not be called.   :Y#
               finalize() must not be called.             :X#
               Garbage collect must be runned.            :X#
               Garbage collect might or might be runned.  :Y#
               Garbage collect must not be runned.        :X#
               code does not compile successful.          :X#
            """, # selection
			"""""", # anser
		],	
		"q21" : [
			"""What does the output of following ? ( single selection )""", # question
			"""~// define class ./Test.java                        \n\n~#
               ~    1: public class Test {                           \n~#
               ~    2:   int cost;                                   \n~#
               ~    3:   public void Test() {                        \n~#
               ~    4:     cost = 4;                                 \n~#
               ~    5:   }                                           \n~#
               ~    6:   public static void main( String[] argu ) {  \n~#
               ~    7:     Test t = new Test();                      \n~#
               ~    8:     System.out.println( t.cost );             \n~#
               ~    9:   }                                           \n~#
               ~       }                                               ~
            """, # code
			"""0                         :Y#
               4                         :X#
               compile fails at line 3.  :X#
               compile fails at line 4.  :X#
               compile fails at line 7.  :X#
               compile fails at line 8.  :X#
               null                      :X#
            """, # selection
			"""""", # anser
		],	
#		"q0X" : [
#			"""""", # question
#			"""""", # code
#			"""""", # selection
#			"""""", # anser
#		],	
	}

}



# ==================================================================================================
# get_all_random method
# ==================================================================================================

def get_all_random ( obj ) : 

	ans_en = [ "A","B","C","D","E","F","G","H","I","J","K","L","M" ];

	# print( "debug using :: obj : " + str( obj ) );
	# print( "debug using :: len( obj ) : " + str( len( obj ) ) );
	index_list = [ o for o in range( len( obj ) ) ];
	obj2       = [];
	# print( "debug using :: index_list : " + str( index_list ) );
	# print( "debug using :: len( index_list ) : " + str( len( index_list ) ) );

	for i in range ( len( obj ) ) : 
		# print( "01 :: choice from :: " + str( index_list ) );
		tmp = random.choice( index_list );
		# print( "02 :: get this o  :: " + str( tmp ) );
		index_list.pop( index_list.index( tmp ) );
		obj2.append( obj[tmp].strip() );
		pass;
		
	obj2 = [ ans_en[ o ] + ": " + obj2[ o ] for o in range( len( obj2 ) ) ];

	# ----------------------------------------
	# debug using :: print tmp2 elements
	# ----------------------------------------
	
	# for s in obj2 :
	# 	tmp = s.strip();
	# 	print( ">>> " + str ( tmp ) );
	# 	pass;
	
	return obj2;
	pass;


# ==================================================================================================
# dict_update method
# ==================================================================================================

def dict_update ( qs_dict, n1 , n2 ) : 

	ans_en = [ "A","B","C","D","E","F","G","H","I","J","K","L","M" ];

	q = qs_dict.get( n1 ).get( n2 )[2].split( "#" );
	q = [ o for o in q if ( len( o.strip() ) > 0 ) ];
	q = get_all_random( q );
	a = [];
	index = 0;
	for s in q :
		tmp = s.strip();
		# print( ">>> " + str ( tmp ) );
		if( ":Y" in s ) : 
			a.append( ans_en[ index ] );
		q[ index ] = s[ 0:-2 ].strip();
		index += 1;
		pass;
		
	q2 = qs_dict.get( n1 ).get( n2 )[1];
	q2 = "".join( [ o.strip()[ 1:-1 ] for o in q2.split( "#" ) if ( len( o ) > 0 ) ] );

	qs_dict.get( n1 ).update( { n2 : [ 
		                                     qs_dict.get( n1 ).get( n2 )[0] , 
		                                     q2                               , 
		                                     q                                ,
		                                     a                                ,
		                                   ]
		                          } 
		                       );
		                       
	# print( "debug using :: q : " + str( q   ) );
	# print( "debug using :: a : " + str( a   ) );
	# print( "debug using :: qs_dict : " + str( qs_dict ) );
	
	pass;

	
Q_index = [ "", "Q01","Q02","Q03","Q04","Q05","Q06","Q07","Q08","Q09","Q10","Q11","Q12","Q13","Q14","Q15", ];
q_index = [ "", 
	"q01","q02","q03","q04","q05","q06","q07","q08","q09","q10","q11","q12","q13","q14","q15", 
	"q16","q17","q18","q19","q20","q21","q22","q23","q24","q25","q26","q27","q28","q29","q30", 
	"q31","q32","q33","q34","q35","q36","q37","q38","q39","q40","q41","q42","q43","q44","q45", 
];



# ==================================================================================================
# q0101
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 1 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) )


# ==================================================================================================
# q0102
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 2 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0103
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 3 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0104
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 4 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0105
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 5 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0106
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 6 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0107
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 7 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0108
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 8 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0109
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 9 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0110
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 10 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0111
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 11 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0112
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 12 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0113 none this
# ==================================================================================================


# ==================================================================================================
# q0114
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 14 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0115
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 15 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0116
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 16 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0117
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 17 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0118
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 18 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0119
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 19 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0120
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 20 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );


# ==================================================================================================
# q0121
# ==================================================================================================

dict_update ( qs_dict, Q_index[ 1 ] , q_index[ 21 ] );
# print( "debug using :: qs_dict : " + str( qs_dict ) );

def get_dict () :
	return qs_dict;
	pass;


