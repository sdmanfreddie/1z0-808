
package lib.worker;

public class Test {
  public static void main ( String[] argu ) {
    System.out.println( "Hello, man !" );
  }
}
