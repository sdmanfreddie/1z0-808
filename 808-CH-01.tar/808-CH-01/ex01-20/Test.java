public class Test {

  public void finalize() {
    System.out.println( "Test.Finalize method be called ! " );

  } // end mehtod finalize

  public static void main ( String[] argu ) {
    System.out.println( "Test.man      method be called ! " );
    Test test = new Test();
    test.printer( test );
    test = null;
    System.gc();

  } // end method main

  private void printer ( Object obj ) {
  	System.out.println( obj );
  	System.exit( 0 );

  } // end method printer

} // enc class Test
