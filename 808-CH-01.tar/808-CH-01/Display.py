#!/bin/python3

from ch01_qs import get_dict;
import os;
import sys;
import subprocess;
import time;

# print( get_dict() );

q_index = [ "", 
	"q01","q02","q03","q04","q05","q06","q07","q08","q09","q10","q11","q12","q13","q14","q15", 
	"q16","q17","q18","q19","q20","q21","q22","q23","q24","q25","q26","q27","q28","q29","q30", 
	"q31","q32","q33","q34","q35","q36","q37","q38","q39","q40","q41","q42","q43","q44","q45", 
];


# ==================================================================================================
# Display question ::
# ==================================================================================================

Q01_dict = get_dict();

Q01_q01_len = len( Q01_dict.get( "Q01" ) );

# print( "debug using :: [" + str( Q01_q01_len ) + "]" );

index = 0;

cmd = "";

displayed = False;

max_index = int( Q01_dict.get( "Q01" ).get( "max" ) );
min_index = 1;

while ( True ) :

	try :
	
	
		# ------------------------------------------------------------------------------------------
		#   info :: input cmd
		# ------------------------------------------------------------------------------------------

		displayed = False;
		# print( "debug using :: index :: " + str( index ) );
		
		if ( index == 0 and displayed == False ) : 
			print( "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" );
			cmd = input( "(" + str( index ) + ") Please n to next, q to exit. $ " );
			displayed = True;
			pass;
			
		if ( index == max_index and displayed == False ) : 
			print( "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" );
			cmd = input( "(" + str( index ) + ") Please p to preview, q to exit. $ " );
			displayed = True;
			pass;
			
		if ( displayed == False ) : 
			print( "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" );
			cmd = input( "(" + str( index ) + ") Please n to next, p to preview, q to exit. $ " );
			displayed = True;
			pass;

		# print( "debug using :: new cmd :: " + str( cmd ) );
	
	
		# ------------------------------------------------------------------------------------------
		#   info :: run cmd n
		# ------------------------------------------------------------------------------------------

		if( cmd == "n" ) :
			os.system( "clear;" );
			index += 1;
			if( index > max_index ) :
				index = max_index;
				print( "This is last question ! (" + str( index ) + ")" );
				pass;
				
			else :
				# print( "Show next question (" + str( index ) + ")" );
				pass;
				
			pass;
	
	
		# ------------------------------------------------------------------------------------------
		#   info :: run cmd p
		# ------------------------------------------------------------------------------------------

		if( cmd == "p" ) :
			os.system( "clear;" );
			index -= 1;
			if( index < min_index ) :
				index = min_index;
				print( "This is first question ! (" + str( index ) + ")" );
				pass;
				
			else :
				# print( "Show preview question (" + str( index ) + ")" );
				pass;
				
			pass;
			
		if( cmd == "q" ) :
			print( "Bye~ see you !" );
			break;
			sys.exit( 0 );
			pass;
			
			
		# ------------------------------------------------------------------------------------------
		#   info :: show question
		# ------------------------------------------------------------------------------------------

		obj = Q01_dict.get( "Q01" ).get( q_index[ index ] );
		
		print( "\n##################################################################### " );
		print(   " : Q : " + str( index ) + " " )
		print(   "##################################################################### " );
		
		# A :: question
		print( "" );
		print( "(" + str( index ) + ") :: " + obj[0] );
		print( "" );

		# B :: code
		if( len( obj[1] ) > 0 ) : 
			print( obj[1] );
		print( "" );

		# C :: selection
		for s in obj[2] :
			print( s );
			print( "" );
		print( "" );

		# D :: anser
		# for s in obj[3] :
		# 	print( s );
			
			
		# ------------------------------------------------------------------------------------------
		#   info :: anser
		# ------------------------------------------------------------------------------------------

		
		while ( True ) :
		
			r_ans = list( obj[3] );
			
			ck = False;
		
			# print( "debug using :: re try inner while :: " );
					
			print( "\n_____________________________________________________________________" );
			ans = input( "(" + str( index ) + ") Please anser ( remember add space ) $" );
			
			ans_list = [];
			
			for i in ans : 
				ans_list.append( i );
				pass;
			
			ans_list = [ o.upper() for o in ans_list if ( len( o.strip() ) > 0 ) ];
				
			# print( "debug using :: your anser = " + str( ans_list ) );
			
			if( len( ans_list ) != len( obj[3] ) ) :
				print( "\n=====================================================================" );
				ans = print( "Wrong  anser !! $" );
				print( "=====================================================================" );
				continue;
				pass;
			
			for i in ans_list : 
				
				if ( i in r_ans ) : 
				
					r_ans.remove( i );
					# print( "debug using :: r_ans remove this :: [" + i + "], new r_ans :: [" + str( r_ans ) + "]" );
					# print( "debug using :: len( r_ans ) ?? " + str( len( r_ans ) ) );
					
					if( len( r_ans ) == 0 ) : 
						print( "\n\t=============================================================" );
						print( "\tRright anser !! $ ( " + str( index ) + " / " + str( max_index ) + " )" );
						print( "\t=============================================================" );
						ck = True;
						pass;
				
					pass;
					
				pass;
			
			if ( not ck ) :
			
				print( "\n\t=============================================================" );
				print( "\tWrong  anser !! $ ( " + str( index ) + " / " + str( max_index ) + " )" );
				print( "\t=============================================================" );
				
				pass;
				
			else :
			
				break;
			
				pass;
						
			pass; # end inner while
			
		pass; # end try
		
	except : 
	
		print( "none this question ::: " );
	
		pass; # end except
		
	pass; # end outer while
	
	
