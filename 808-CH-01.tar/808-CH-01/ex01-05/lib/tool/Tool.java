package lib.tool;
public class Tool {}
