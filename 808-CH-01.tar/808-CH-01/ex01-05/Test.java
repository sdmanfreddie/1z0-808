
//case A.
	// replace using import lib.*;

//case B.
	// import lib.*.Tool;

//case C.
	import lib.tool.Tool;

//case D.
	// import lib.tool.*;

//case E.
	// import lib.tool.Tool.*;
	
public class Test {
  public void run ( Tool tool ) {
    System.out.println( tool );
  }
  public static void main ( String[] argu ) {
    new Test().run( new Tool() );
  }
}
